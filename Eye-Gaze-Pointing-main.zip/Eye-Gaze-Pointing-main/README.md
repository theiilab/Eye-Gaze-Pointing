# Eye-Gaze-Pointing
Design and Evaluation of a Silent Speech-Based Selection Method for Eye-Gaze Pointing
